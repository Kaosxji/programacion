using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camarafollow : MonoBehaviour
{
    //Atrivuto Publico
    public Transform pelota;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(
            pelota.position.x,
            pelota.position.y,
            -1);  
    }
}
